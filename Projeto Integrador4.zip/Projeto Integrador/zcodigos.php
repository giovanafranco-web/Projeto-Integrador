<?php
function conectarBancoDeDados ()
{
    $conn = new mysqli{ 

    }
}
