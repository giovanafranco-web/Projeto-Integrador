<?php include "zbanco_dados.php"; ?>
<?php verificarPagamento(); ?>

<h1>Catálogo de Filmes</h1>

<?php
$filmes = buscarFilmes();
while ($f = $filmes->fetch_assoc()):
?>

<div style="border:1px solid #ccc; margin:10px; padding:10px;">
    <img src="<?= $f['capa'] ?>" width="150"><br>
    <h3><?= $f['titulo'] ?></h3>
    <p><?= $f['descricao'] ?></p>
    <a href="<?= $f['video_url'] ?>">Assistir</a>
</div>

<?php endwhile; ?>
