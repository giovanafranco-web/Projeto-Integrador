<?php include "zbanco_dados.php"; ?>
<?php verificarLogin(); ?>

<?php
$u = buscarUsuario($_SESSION['usuario_id']);
?>

<h1>Minha Conta</h1>
<p>Nome: <?= $u['nome'] ?></p>
<p>Email: <?= $u['email'] ?></p>
<p>Plano: <b><?= $u['plano'] ?></b></p>

<a href="zassinaturas.php">Mudar Assinatura</a>
