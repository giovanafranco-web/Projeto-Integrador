<?php include "zbanco_dados.php"; ?>
<?php verificarLogin(); ?>

<h1>Área Restrita</h1>

<?php
$usuario = buscarUsuario($_SESSION['usuario_id']);
echo "<p>Olá, <b>{$usuario['nome']}</b>!</p>";
echo "<p>Plano atual: <b>{$usuario['plano']}</b></p>";
?>

<a href="zfilmes.php">Acessar Filmes</a><br>
<a href="zminhaconta.php">Minha Conta</a><br>
<a href="zlogout.php">Sair</a>
