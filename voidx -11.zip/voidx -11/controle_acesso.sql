CREATE TABLE acesso_planos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  recurso VARCHAR(100) NOT NULL,
  plano_minimo ENUM('gratis','padrao','premium') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO acesso_planos (recurso, plano_minimo) VALUES
('assistir_filme', 'gratis'),
('sem_anuncios', 'padrao'),
('hd', 'padrao'),
('4k', 'premium'),
('download', 'premium');
