CREATE TABLE suporte (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT,
  assunto VARCHAR(120) NOT NULL,
  mensagem TEXT NOT NULL,
  status ENUM('aberto','respondido','fechado') DEFAULT 'aberto',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
