<?php
include "zbanco_dados.php";
verificarLogin();

$conn = conectarBanco();
$usuario = buscarUsuario($_SESSION['usuario_id']);

if (isset($_GET['plano'])) {
    $novoPlano = $_GET['plano'];
    $planosValidos = ['gratis','padrao','premium'];

    if (in_array($novoPlano, $planosValidos) && $novoPlano !== $usuario['plano']) {
        $log = $conn->prepare("INSERT INTO assinaturas_log (usuario_id, plano_anterior, plano_novo) VALUES (?, ?, ?)");
        $log->bind_param("iss", $_SESSION['usuario_id'], $usuario['plano'], $novoPlano);
        $log->execute();

        $upd = $conn->prepare("UPDATE usuarios SET plano = ? WHERE id = ?");
        $upd->bind_param("si", $novoPlano, $_SESSION['usuario_id']);
        $upd->execute();

        header("Location: zminhaconta.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Atualizando Assinatura</title>
<link rel="stylesheet" href="estilos/css.css">
</head>
<body>

<header class="cabecalho">
    <h1>VoidX</h1>
    <p>Processando sua assinatura...</p>
</header>

<main style="text-align:center; margin-top:60px;">
    <h2>Plano atual: <?= strtoupper($usuario['plano']) ?></h2>
    <p>Escolha um novo plano na página de assinaturas.</p>
    <a href="assinaturas.html">Voltar</a>
</main>

</body>
</html>
