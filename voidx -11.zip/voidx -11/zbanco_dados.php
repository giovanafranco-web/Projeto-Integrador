<?php
session_start();

// Conexão ao MySQL
function conectarBanco() {
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "filmesdb";

    $conn = new mysqli($host, $user, $pass, $db);
    if ($conn->connect_error) {
        die("Erro ao conectar: " . $conn->connect_error);
    }
    return $conn;
}

// Buscar usuário por ID
function buscarUsuario($id) {
    $conn = conectarBanco();
    $sql = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
    $sql->bind_param("i", $id);
    $sql->execute();
    return $sql->get_result()->fetch_assoc();
}

// Verifica se está logado
function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) {
        header("Location: zlogin.php");
        exit();
    }
}

// Verifica assinatura
function verificarPagamento() {
    verificarLogin();

    $usuario = buscarUsuario($_SESSION['usuario_id']);
    if ($usuario['plano'] == "gratis") {
        echo "<h2>Assinatura necessária para acessar esta página.</h2>";
        exit();
    }
}

// Buscar todos os filmes
function buscarFilmes() {
    $conn = conectarBanco();
    return $conn->query("SELECT * FROM filmes ORDER BY id DESC");
}

// Cadastrar usuário
function cadastrarUsuario($nome, $email, $senha) {
    $conn = conectarBanco();
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

    $sql = $conn->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
    $sql->bind_param("sss", $nome, $email, $senhaHash);
    return $sql->execute();
}

// Login
function loginUsuario($email, $senha) {
    $conn = conectarBanco();
    $sql = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
    $sql->bind_param("s", $email);
    $sql->execute();

    $result = $sql->get_result();
    if ($result->num_rows == 0) return false;

    $user = $result->fetch_assoc();

    if (password_verify($senha, $user['senha'])) {
        $_SESSION['usuario_id'] = $user['id'];
        return true;
    }
    return false;
}
?>
