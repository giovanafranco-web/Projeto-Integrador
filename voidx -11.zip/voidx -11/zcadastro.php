<?php include "zbanco_dados.php"; ?>

<?php
if ($_POST) {
    if (cadastrarUsuario($_POST['nome'], $_POST['email'], $_POST['senha'])) {
        echo "<h3>Cadastro concluído! Agora faça login.</h3>";
    } else {
        echo "<h3>Erro ao cadastrar.</h3>";
    }
}
?>

<h1>Cadastro</h1>
<form method="POST">
    <input type="text" name="nome" placeholder="Nome" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="senha" placeholder="Senha" required><br>
    <button type="submit">Cadastrar</button>
</form>
