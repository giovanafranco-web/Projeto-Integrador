<?php
include "zbanco_dados.php"; 
verificarLogin();


$usuario = buscarUsuario($_SESSION['usuario_id']);


if ($_POST['acao'] == 'atualizar_foto' && isset($_FILES['foto'])) {
    $foto = $_FILES['foto'];
    $fotoNome = $_SESSION['usuario_id'] . "_" . time() . ".jpg"; 
    move_uploaded_file($foto['tmp_name'], "uploads/" . $fotoNome);

    $conn = conectarBanco();
    $sql = $conn->prepare("UPDATE usuarios SET foto = ? WHERE id = ?");
    $sql->bind_param("si", $fotoNome, $_SESSION['usuario_id']);
    $sql->execute();
    header("Location: minhaconta.php"); 
    exit();
}

if ($_POST['acao'] == 'atualizar_dados') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];

    if (!empty($senha)) {
        $senha = password_hash($senha, PASSWORD_BCRYPT); 
    } else {
        $senha = null; 
    }

    $conn = conectarBanco();
    if ($senha) {
        $sql = $conn->prepare("UPDATE usuarios SET nome = ?, email = ?, usuario = ?, senha = ? WHERE id = ?");
        $sql->bind_param("ssssi", $nome, $email, $usuario, $senha, $_SESSION['usuario_id']);
    } else {
        $sql = $conn->prepare("UPDATE usuarios SET nome = ?, email = ?, usuario = ? WHERE id = ?");
        $sql->bind_param("sssi", $nome, $email, $usuario, $_SESSION['usuario_id']);
    }
    $sql->execute();
    header("Location: minhaconta.php"); 
    exit();
}

function buscarUsuario($id) {
    $conn = conectarBanco();
    $sql = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
    $sql->bind_param("i", $id);
    $sql->execute();
    $resultado = $sql->get_result();
    return $resultado->fetch_assoc();
}
?>
