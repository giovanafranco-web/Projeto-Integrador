<?php
include "zbanco_dados.php";

if ($_POST) {
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];

    $conn = conectarBanco();

    $sql = $conn->prepare(
        "SELECT * FROM controle_acesso WHERE usuario = ? AND senha = ?"
    );
    $sql->bind_param("ss", $usuario, $senha);
    $sql->execute();
    $res = $sql->get_result();

    if ($res->num_rows == 1) {
        session_start();
        $_SESSION['admin'] = $usuario;
        header("Location: restrito-painel.php");
        exit();
    }

    header("Location: restrita.html");
    exit();
}
