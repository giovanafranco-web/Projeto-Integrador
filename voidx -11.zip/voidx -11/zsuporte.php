<?php
include "zbanco_dados.php";

if ($_POST) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $mensagem = $_POST['mensagem'];

    $conn = conectarBanco();

    $sql = $conn->prepare(
        "INSERT INTO suporte (nome, email, mensagem, data_envio) VALUES (?, ?, ?, NOW())"
    );
    $sql->bind_param("sss", $nome, $email, $mensagem);
    $sql->execute();

    header("Location: suporte.html");
    exit();
}
