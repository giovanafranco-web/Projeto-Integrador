<?php

// Como é que começamos a implementar a lógica de area protegida, formulario de  contato e visualização das mensagens?

//Primeira coisa: criar um banco de dados!
//O que vai ter nesse banco de dados? Tabela: usuario; Tabela: mensagem (vai depender de como você implementar!)
//Se tivessemos uma tabela de filme: precisariamos das informações comuns a todos os filmes
//Quais sao as propriedades que descrevem um filme? Titulo; Sinopse; Imagem; Ano; Diretor 
//Do mesmo jeito que nas aulas nos buscamos um contato com o PHP, nos vamos buscar um filme - e processar as informacoes do banco em uma pagina Filme.php (por exemplo)


//imagem -> no banco, vira um link hospedagem/imagens/titulo_filme/imagem.png


//tabela filmes

//id_filme | titulo | sinopse | imagem_filme | diretor | genero | duracao
// 1       | sonic  | um ourico... | link/sonic.png | alguem | aventura | 1h30
// 2       | senhor dos aneis  | um hobbit... | link/senhor_aneis.png | alguem | aventura | 2h30


//tabela usuarios
//id | nome | email | senha | genero
//

//tabela pagamentos
//id | id_usuario | valor | data 
//

//na sua pagina filmes.php, depois do banco de dados estar criado, teriamos algo como:

/*

conectarBanco();

$lista_filmes = buscar_filmes();

foreach ($filmes: $lista_filmes) {
    //no meio disso aqui tem o nosso cõdigo de exibicao!
    echo "filme_id"
    echo "filme_id"

    echo "assistir!" <link filme.php?id=
}



buscar_filmes() {
    $resultados = select * from filmes;
    return $resultados

}


essa pagina acima mostra a listagem de TODOS os filmes!

//e se eu quiser ver um filme só?

