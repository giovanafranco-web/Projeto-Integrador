<?php include "zbanco_dados.php"; ?>
<?php verificarLogin(); ?>

<h1>Assinaturas</h1>

<form method="POST">
    <select name="plano">
        <option value="gratis">Gratis</option>
        <option value="premium">Premium</option>
    </select>
    <button type="submit">Salvar</button>
</form>

<?php
if ($_POST) {
    $conn = conectarBanco();
    $sql = $conn->prepare("UPDATE usuarios SET plano = ? WHERE id = ?");
    $sql->bind_param("si", $_POST['plano'], $_SESSION['usuario_id']);
    $sql->execute();
    echo "<h3>Plano atualizado!</h3>";
}
?>
