<?php include "zbanco_dados.php"; ?>

<?php
if ($_POST) {
    if (loginUsuario($_POST['email'], $_POST['senha'])) {
        header("Location: zrestrita.php");
        exit();
    } else {
        echo "<h3>Email ou senha incorretos!</h3>";
    }
}
?>

<h1>Login</h1>
<form method="POST">
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="senha" placeholder="Senha" required><br>
    <button type="submit">Entrar</button>
</form>
