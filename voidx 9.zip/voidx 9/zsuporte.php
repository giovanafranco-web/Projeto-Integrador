<?php include "zbanco_dados.php"; ?>
<?php verificarLogin(); ?>

<h1>Suporte</h1>

<form method="POST">
    <textarea name="mensagem" required></textarea><br>
    <button type="submit">Enviar Mensagem</button>
</form>

<?php
if ($_POST) {
    $conn = conectarBanco();
    $sql = $conn->prepare("INSERT INTO suporte (usuario_id, mensagem) VALUES (?, ?)");
    $sql->bind_param("is", $_SESSION['usuario_id'], $_POST['mensagem']);
    $sql->execute();
    echo "<h3>Mensagem enviada!</h3>";
}
?>
